import logging
import os
import re
from typing import List

import numpy as np
import yaml

import loompy
import re


class Annotation:
    unknown_tags: set = set()

    def __init__(self, category: str, filename: str) -> None:
        with open(filename) as f:
            doc = next(yaml.load_all(f, Loader=yaml.SafeLoader))

        if "name" in doc:
            self.name = doc["name"]
        else:
            raise ValueError(os.path.basename(filename) + " did not contain a 'name' attribute, which is required.")

        if "abbreviation" in doc:
            self.abbreviation = doc["abbreviation"]
        else:
            raise ValueError(os.path.basename(filename) + " did not contain an 'abbreviation' attribute, which is required.")

        if "definition" in doc:
            self.definition = doc["definition"]
            genes = self.definition.strip().split()
            self.positives = [x[1:] for x in genes if x.startswith("+")]
            self.negatives = [x[1:] for x in genes if x.startswith("-")]
            self.or_positives =[]
            for i in genes:
                or_cond = re.search(r"\((.*?)\)", i)
                if or_cond !=None:
                    or_combination = or_cond.group(1)
                    or_combination = or_combination.split('+')[1:]
                    self.or_positives.append([or_combination]) 
        else:
            raise ValueError(os.path.basename(filename) + " did not contain a 'definition' attribute, which is required.")

        if "categories" in doc and doc["categories"] is not None:
            self.categories = re.split(r"\W+", doc["categories"].strip())
        else:
            self.categories = []

    def __str__(self) -> str:
        temp = self.name + " (" + self.abbreviation + "; " + " ".join(["+" + x for x in self.positives])
        if len(self.negatives) > 0:
            temp = temp + " " + " ".join(["-" + x for x in self.negatives]) + ")"
        else:
            temp = temp + ")"
        return temp


class AutoAnnotator(object):
    def __init__(self, root: str,\
        connect:str,\
        ds: loompy.LoomConnection = None,shoji=None,ws=None) -> None: 
        self.root = root
        self.definitions: List[Annotation] = []

        if connect=='ds':
            self.genes: List[str] = [] if ds is None else ds.ra.Gene
            self.accessions: List[str] = [] if ds is None else ds.ra.Accession
            self.annotations = None  # type: np.ndarray
        elif connect=='shoji':
            gene = shoji['shoji']['Gene'][:]
            gene = np.array([i.decode('UTF-8') for i in gene])
            self.genes: List[str] = gene

            acc = shoji['shoji']['Accession'][:]
            acc = np.array([i.decode('UTF-8') for i in acc])
            self.accessions: List[str] = acc#[] if ds is None else ds.ra.Accession

            self.annotations = None 
        elif connect=='ws':
            self.genes = ws.Gene[:]
            self.accessions = ws.Accession[:]

            self.annotations = None 

        fileext = [".yaml", ".md"]
        root_len = len(self.root)
        for cur, dirs, files in os.walk(self.root):
            # so no hidden files and folder
            dirs[:] = [d for d in dirs if not d[0] == '.']
            files = [f for f in files if not f[0] == '.']
            for file in files:
                errors = False
                if os.path.splitext(file)[-1] in fileext and file[-9:] != "README.md" and file[0] != '.': # so no hidden files
                    try:
                        tag = Annotation(cur[root_len:], os.path.join(cur, file))
                        # print(tag)
                        for pos in tag.positives:
                            if len(self.genes) > 0 and (pos not in self.genes and pos not in self.accessions):
                                logging.error(file + ": gene '%s' not found in file", pos)
                                errors = True
                        for neg in tag.negatives:
                            if len(self.genes) > 0 and (neg not in self.genes and neg not in self.accessions):
                                logging.error(file + ": gene '%s' not found in file", neg)
                                errors = True
                        for cond in range(len(tag.or_positives)):
                            for pos in np.ravel(tag.or_positives[cond]):
                                if len(self.genes) > 0 and (pos not in self.genes and pos not in self.accessions):
                                    logging.error(file + ": gene '%s' not found in file", pos)
                                    errors = True
                        if not errors:
                            self.definitions.append(tag)
                    except Exception as e:
                        logging.error(file + ": " + str(e))
                        errors = True
        # if errors:
        # 	raise ValueError("Error loading cell tag definitions")

    def fit(self, connect:str,clusters:np.array=None, \
        ds: loompy.LoomConnection=None, shoji=None,ws=None) -> np.ndarray:
        """
        Return the annotation for an already aggregated and trinarized loom file

        The input file should have one column per cluster and a layer named "trinaries"

        Returns:
            An array of strings giving the auto-annotation for each cluster
        """

        if connect=='ds': 
            self.genes = ds.ra.Gene
            self.accessions = ds.ra.Accession
            trinaries = ds.layers["trinaries"]
        elif connect=='shoji': 
            gene = shoji['shoji']['Gene'][:]
            gene = np.array([i.decode('UTF-8') for i in gene])
            self.genes: List[str] = gene

            acc = shoji['shoji']['Accession'][:]
            acc = np.array([i.decode('UTF-8') for i in acc])
            self.accessions: List[str] = acc

            trinaries = shoji['shoji']["Trinaries"][:].T
        elif connect=='ws':
            self.genes = ws.Gene[:]
            trinaries = ws.Trinaries[:].T
            self.accessions = ws.Accession[:]

        if clusters is not None:
            trinaries = trinaries[:,clusters]

        self.annotations = np.empty((len(self.definitions), trinaries.shape[1]))
        for ix, tag in enumerate(self.definitions):
            for cluster in range(trinaries.shape[1]):
                p = 1
                for pos in tag.positives:
                    if pos not in self.genes and pos not in self.accessions:
                        logging.error(f"Auto-annotation gene {pos} (used for {tag}) not found in file")
                        continue
                    if pos in self.genes:
                        index = np.where(self.genes == pos)[0][0]
                    else:
                        index = np.where(self.accessions == pos)[0][0]
                    p = p * trinaries[index, cluster] # assuming they are mutually exlusive 
                for cond in range(len(tag.or_positives)):
                    p_cond=[]
                    for pos in np.ravel(tag.or_positives[cond]):
                        if pos not in self.genes and pos not in self.accessions:
                            logging.error(f"Auto-annotation gene {pos} (used for {tag}) not found in file")
                            continue
                        if pos in self.genes:
                            index = np.where(self.genes == pos)[0][0]
                        else:
                            index = np.where(self.accessions == pos)[0][0]
                        p_cond.append(trinaries[index,cluster])
                    and_p = np.prod(p_cond)
                    sum_p = np.sum(p_cond)
                    p = p * (sum_p - and_p) # for each combination of genes i.e. (+A+B) and (+C+D)
                for neg in tag.negatives:
                    if neg not in self.genes and neg not in self.accessions:
                        logging.error(f"Auto-annotation gene {neg} (used for {tag}) not found in file")
                        continue
                    if neg in self.genes:
                        index = np.where(self.genes == neg)[0][0]
                    else:
                        index = np.where(self.accessions == neg)[0][0]
                    p = p * (1 - trinaries[index, cluster])
                self.annotations[ix, cluster] = p

        attr = []
        for ix in range(self.annotations.shape[1]):
            tags = []  # type: List[str]
            for j in range(self.annotations.shape[0]):
                if self.annotations[j, ix] > 0.5:
                    tags.append(self.definitions[j].abbreviation)
            tags.sort()
            attr.append(" ".join(tags))

        return np.array(attr)

    def annotate(self, ds: loompy.LoomConnection) -> None:
        """
        Annotate an aggregated and trinarized loom file


        Remarks:
            Creates the following new column attributes:
                AutoAnnotation:		Space-separated list of auto-annotation labels

        The input file should have one column per cluster and a layer named "trinaries"

        """
        ds.ca.AutoAnnotation = self.fit(ds)
