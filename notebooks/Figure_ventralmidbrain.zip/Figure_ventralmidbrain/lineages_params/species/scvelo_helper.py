import sys
import os
import sys
current_dir = os.getcwd()
sys.path.append(current_dir)
from human import cc_genes_human,g1_human,s_human,g2m_human,TFs_human


mask_genes ={
    "TFs": TFs_human,
    "cellcycle": cc_genes_human,
    "sex": ["XIST", "TSIX"],
    "ieg": ['JUNB', 'FOS', 'EGR1', 'JUN'],
    "g1": g1_human,
    "s": s_human,
    "g2m": g2m_human,
    "ery": ["HBA-A1", "HBA-A2", "HBA-X", "HBB-BH1", "HBB-BS", "HBB-BT", "HBB-Y", "ALAS2"],
    "mt": ['MT-CYB', 'MT-ND6', 'MT-CO3', 'MT-ND1', 'MT-ND4', 'MT-CO1', 'MT-ND2', 'MT-CO2', 'MT-ATP8', 'MT-ND4L', 'MT-ATP6', 'MT-ND5', 'MT-ND3']
}